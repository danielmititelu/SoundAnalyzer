﻿using System.Windows.Controls;

namespace SoundAnalyzer.UserControls {
    public partial class BassClefUC : UserControl {
        public BassClefUC() {
            InitializeComponent();
        }
    }
}
