﻿using System.Windows.Controls;

namespace SoundAnalyzer.UserControls {
    public partial class TrebleClefUC : UserControl {
        public TrebleClefUC() {
            InitializeComponent();
        }
    }
}
