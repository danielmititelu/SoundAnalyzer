﻿using System.Windows.Controls;

namespace SoundAnalyzer.UserControls {
    public partial class SharpUC : UserControl {
        public SharpUC() {
            InitializeComponent();
        }
    }
}
